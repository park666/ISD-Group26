/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author qingwenxiao
 */
public class Staff{
  private  String id;
  private  String password;
  private  String name;
  private  String email;
  private  String role;
  
  public Staff(){}
  
  public Staff(String id, String password,String name, String email, String role){
      this.id = id;
      this.password = password;
      this.name = name;
      this.email = email;
      this.role = role;
  }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }
   
    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }
      
}
